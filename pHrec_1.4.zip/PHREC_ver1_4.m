function varargout = PHREC_ver1_4(varargin)
% PHREC_ver1_4 MATLAB code for PHREC_ver1_4.fig
%      PHREC_ver1_4, by itself, creates a new PHREC_ver1_4 or raises the existing
%      singleton*.
%
%      H = PHREC_ver1_4 returns the handle to a new PHREC_ver1_4 or the handle to
%      the existing singleton*.
%
%      PHREC_ver1_4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PHREC_ver1_4.M with the given input arguments.
%
%      PHREC_ver1_4('Property','Value',...) creates a new PHREC_ver1_4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PHREC_ver1_4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PHREC_ver1_4_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PHREC_ver1_4

% Last Modified by GUIDE v2.5 06-Mar-2017 12:50:54

% Update log: Ver 1.1 Add the function for pH offset adjustment
%             Ver 1.2 Enables 2 points pH calibration
%             Ver 1.4 Fixed temperature - pH std calculation

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PHREC_ver1_4_OpeningFcn, ...
                   'gui_OutputFcn',  @PHREC_ver1_4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PHREC_ver1_4 is made visible.
function PHREC_ver1_4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PHREC_ver1_4 (see VARARGIN)

% Choose default command line output for PHREC_ver1_4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PHREC_ver1_4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Initilize serial port connection

seriallist = getAvailableComPort();
set(handles.popupmenu1, 'String', seriallist);
% Here a cell function was used to get the string of selection from the popmenu  
global Runstatus;
Runstatus = 0;

% set the frequency of sampling
set(handles.Portstatus,'String','Not connected');
global PH10Cal PH4Cal PH7Cal PHRef PHSTD OFFSET TempC;
PH10Cal = str2num(get(handles.PH10,'String')); 
PH4Cal = str2num(get(handles.PH4,'String')); 
PH7Cal = str2num(get(handles.PH7,'String')); 
PHRef = str2num(get(handles.RefpH,'String'));
PHSTD = str2num(get(handles.RefpHCal,'String'));
TempC = str2num(get(handles.Temperaure,'String'));
OFFSET = PHRef  - PHSTD;
global slope intercept;
x = [PH10Cal; PH7Cal; PH4Cal];
y = [10; 7; 4];
Calconstant = polyfit(x,y,1);
slope = Calconstant(1);
intercept= Calconstant(2);

% Initate chart
cla(handles.axes1);

%------------------------------------------------------------------
function lCOM_Port = getAvailableComPort()
% function lCOM_Port = getAvailableComPort()
% Return a Cell Array of COM port names available on your computer

try
    s=serial('IMPOSSIBLE_NAME_ON_PORT');fopen(s); 
catch
    lErrMsg = lasterr;
end

%Start of the COM available port
lIndex1 = findstr(lErrMsg,'COM');
%End of COM available port
lIndex2 = findstr(lErrMsg,'Use')-3;

lComStr = lErrMsg(lIndex1:lIndex2);

%Parse the resulting string
lIndexDot = findstr(lComStr,',');

% If no Port are available
if isempty(lIndex1)
    lCOM_Port{1}='';
    return;
end

% If only one Port is available
if isempty(lIndexDot)
    lCOM_Port{1}=lComStr;
    return;
end

lCOM_Port{1} = lComStr(1:lIndexDot(1)-1);

for i=1:numel(lIndexDot)+1
    % First One
    if (i==1)
        lCOM_Port{1,1} = lComStr(1:lIndexDot(i)-1);
    % Last One
    elseif (i==numel(lIndexDot)+1)
        lCOM_Port{i,1} = lComStr(lIndexDot(i-1)+2:end);       
    % Others
    else
        lCOM_Port{i,1} = lComStr(lIndexDot(i-1)+2:lIndexDot(i)-1);
    end
end    
%------------------------------------------------------------------

% --- Outputs from this function are returned to the command line.
function varargout = PHREC_ver1_4_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global ard;
ard.analogReference('EXTERNAL');
global freq; 
global Runstatus;
Runstatus = 1;
global recording;
global filename;
global fid;
global calib;
calib = 0;
global data;
global PHdata;
global calibPH PH10Cal PH4Cal PH7Cal PHRef OFFSET;
global slope intercept;
recording = 0;
global reset;
reset = 0;
clear data;
clear PHdata;
global ID;
ID = 1;
Time = 0; % measure the time elapsed
% Initiate plot diagram
cla(handles.axes1);
axes(handles.axes1);
freq = 1;
while Runstatus == 1
    tic;
    if reset == 1
        clear data;
        clear PHdata;
        ID = 1;
        Time = 0;
        cla(handles.axes1);
        reset = 0;
    else
    end
        
        
                 reading = ard.readADC(0);
                 data(ID) = reading;
                 PHreading = slope*reading+intercept;
                 PHdata(ID)= PHreading - OFFSET;
                 set(handles.readingtxt,'String',num2str(PHdata(ID)));
                if recording == 1
                    fid = fopen(filename,'a');
                    fprintf(fid,'%i, %3.1f, %f, %d, %6.3f, %5.1f, %5.1f, %5.1f\r\n', ID, Time(ID) ,now ,data(ID), PHdata(ID),PH10Cal, PH4Cal, PH7Cal);
                    fclose(fid);
                    else
               end
                    % plot the moniter window
%                     temp = csvread(filename);
                    % Plot onto the GUI      
                       Rangeoftime = str2num(get(handles.timerange,'String'));
                    if Time(ID) < Rangeoftime+1 && Time(ID) > 1
                      axes(handles.axes1);
                        minY = min(data)-10;
                        maxY = max(data)+10;
                            set(gcf,'color','white');
                            drawnow;
                            plot(Time,data,'-.o b'), axis([1 Rangeoftime minY maxY]);
                            grid on;
                            xlabel('time (s)');
                            ylabel('signal');
                            
                      axes(handles.axes3);
                        minY = min(PHdata)-0.1;
                        maxY = max(PHdata)+0.1;
                            set(gcf,'color','white');
                            drawnow;
                            plot(Time,PHdata,'-.o r'), axis([1 Rangeoftime minY maxY]);
                            grid on;
                            xlabel('time (s)');
                            ylabel('pH');
                            
                    elseif Time(ID) > Rangeoftime
                        axes(handles.axes1);
                            minY = min(data(ID-(Rangeoftime/freq):ID))-10;
                            maxY = max(data(ID-(Rangeoftime/freq):ID))+10;
                            set(gcf,'color','white');
                            drawnow;
                            plot(Time,data,'-.o b'), axis([Time(ID)-Rangeoftime Time(ID) minY maxY]);
                            grid on;
                            xlabel('time (s)');
                            ylabel('signal');

                        axes(handles.axes3);
                            minY = min(PHdata(ID-(Rangeoftime/freq):ID))-0.1;
                            maxY = max(PHdata(ID-(Rangeoftime/freq):ID))+0.1;
                            set(gcf,'color','white');
                            drawnow;
                            plot(Time,PHdata,'-.o r'), axis([Time(ID)-Rangeoftime Time(ID) minY maxY]);
                            grid on;
                            xlabel('time (s)');
                            ylabel('pH');

                    else    
                    end
                    
                    % set timer right
                    % Decide if avg data for calib
                    
                    switch calib
                        case 0
                        case 1;
                        currentID = ID;
                        calib = 2;
                        Calcount = 1;
                        Calibdata = zeros(10,1);
                        case 2
                        if Calcount < 11
                            Calibdata(Calcount) = data(currentID+Calcount-1);
                            Calcount = Calcount +1;
                        elseif Calcount == 11
                            calib = 0;
                                switch calibPH
                                    case 'PH10'
                                        PH10Cal = mean(Calibdata);
                                        set(handles.PH10,'String',num2str(PH10Cal));
                                    case 'PH4'
                                        PH4Cal = mean(Calibdata);
                                        set(handles.PH4,'String',num2str(PH4Cal));
                                    case 'PH7'
                                        PH7Cal = mean(Calibdata);
                                        set(handles.PH7,'String',num2str(PH7Cal));
                                    case 'Ref'
                                        PHRef = slope*mean(Calibdata)+intercept;
                                        set(handles.RefpH,'String',num2str(PHRef));
                                end
                         
                        end 
                    end
                        
                    
                    Time(ID +1) = Time(ID) + freq;
                    ID = ID+1;
                    toc;
                    pause(freq-toc);
               
end


% --- Executes on button press in pushbutton2.

function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ard;
global Runstatus;
Runstatus = 0;


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in connectBTN.
function connectBTN_Callback(hObject, eventdata, handles)
% hObject    handle to connectBTN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global serialport
serialport  = feval(@(x) x{1}{x{2}},get(handles.popupmenu1,{'String','Value'}))
global ard;

set(handles.Portstatus,'String','Connecting...')
ard = arduino(serialport);
set(handles.Portstatus,'String','Connected!');


% --- Executes on button press in disconnectBTN.
function disconnectBTN_Callback(hObject, eventdata, handles)
% hObject    handle to disconnectBTN (see GCBO)
global serialport
delete(instrfind({'Port'},{serialport}));
seriallist = getAvailableComPort();
set(handles.popupmenu1, 'String', seriallist);
set(handles.Portstatus,'String','Not connected');
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes during object creation, after setting all properties.

% --- Executes on button press in Setfreq.


function PH10_Callback(hObject, eventdata, handles)
% hObject    handle to PH10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PH10 as text
%        str2double(get(hObject,'String')) returns contents of PH10 as a double


% --- Executes during object creation, after setting all properties.
function PH10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PH10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PH4_Callback(hObject, eventdata, handles)
% hObject    handle to PH4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PH4 as text
%        str2double(get(hObject,'String')) returns contents of PH4 as a double


% --- Executes during object creation, after setting all properties.
function PH4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PH4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PH7_Callback(hObject, eventdata, handles)
% hObject    handle to PH7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PH7 as text
%        str2double(get(hObject,'String')) returns contents of PH7 as a double


% --- Executes during object creation, after setting all properties.
function PH7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PH7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in GPH10.
function GPH10_Callback(hObject, eventdata, handles)
% hObject    handle to GPH10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global calibPH;
global calib;
calibPH = 'PH10';
calib = 1;



% --- Executes on button press in GPH4.
function GPH4_Callback(hObject, eventdata, handles)
% hObject    handle to GPH4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global calibPH;
global calib;
calibPH = 'PH4';
calib = 1;

% --- Executes on button press in GPH7.
function GPH7_Callback(hObject, eventdata, handles)
% hObject    handle to GPH7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global calibPH;
global calib;
calibPH = 'PH7';
calib = 1;


% --- Executes on button press in clacph.
function clacph_Callback(hObject, eventdata, handles)
% hObject    handle to clacph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  PH10Cal PH7Cal PH4Cal slope intercept PHRef PHSTD OFFSET ;
% Check if a two points pH calibration was selected
check = get(handles.Calib_2p,'Value');
T = get(handles.Temperaure,'String');
T = str2num(T)+273.15;
PH4STD = (4.34E-5)*T^2-(2.48E-2)*T+7.54;
PH7STD = (5.825E-5)*T^2-(3.8E-2)*T+13.153;
PH10STD = (1E-4)*T^2-(6.94E-2)*T+21.8;
if check == 0
    PH10Cal = str2num(get(handles.PH10,'String')); 
    PH4Cal = str2num(get(handles.PH4,'String')); 
    PH7Cal = str2num(get(handles.PH7,'String')); 
    PHRef = str2num(get(handles.RefpH,'String'));
    PHSTD = str2num(get(handles.RefpHCal,'String'));
    OFFSET = PHRef  - PHSTD;
    x = [PH10Cal; PH7Cal; PH4Cal];
    y = [PH10STD; PH7STD; PH4STD];
else
    PH10Cal = str2num(get(handles.PH10,'String')); 
    PH7Cal = str2num(get(handles.PH7,'String')); 
    PHRef = str2num(get(handles.RefpH,'String'));
    PHSTD = str2num(get(handles.RefpHCal,'String'));
    OFFSET = PHRef  - PHSTD;
    x = [PH10Cal; PH7Cal];
    % 20C
    y = [PH10STD; PH7STD];
    % 25C
    % y = [10.01; 7];
end
Calconstant = polyfit(x,y,1);
slope = Calconstant(1);
intercept= Calconstant(2);
 axes(handles.axes2);
 cla(handles.axes2);
 plot(x,y,'o');
 hold on
 plot(x,y,'-.r');
 hold off
 


% --- Executes on button press in recording.
function recording_Callback(hObject, eventdata, handles)
% hObject    handle to recording (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global recording;
global filename;
global fid;
global reset;
s = datevec(now);
filename = strcat(num2str(s(2)),'-',num2str(s(3)),',',num2str(s(4)),'hr',num2str(s(5)),'min.txt');
fid = fopen(filename,'w');
fclose(fid);
recording = 1;
reset = 1;




% --- Executes on button press in stoprecoring.
function stoprecoring_Callback(hObject, eventdata, handles)
% hObject    handle to stoprecoring (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global recording;
recording = 0;



function RefpHCal_Callback(hObject, eventdata, handles)
% hObject    handle to RefpHCal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RefpHCal as text
%        str2double(get(hObject,'String')) returns contents of RefpHCal as a double


% --- Executes during object creation, after setting all properties.
function RefpHCal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RefpHCal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in GetRefpH.
function GetRefpH_Callback(hObject, eventdata, handles)
% hObject    handle to GetRefpH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global calibPH;
global calib;
calibPH = 'Ref';
calib = 1;


function RefpH_Callback(hObject, eventdata, handles)
% hObject    handle to RefpH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RefpH as text
%        str2double(get(hObject,'String')) returns contents of RefpH as a double


% --- Executes during object creation, after setting all properties.
function RefpH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RefpH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function timerange_Callback(hObject, eventdata, handles)
% hObject    handle to timerange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timerange as text
%        str2double(get(hObject,'String')) returns contents of timerange as a double


% --- Executes during object creation, after setting all properties.
function timerange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timerange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Calib_2p.
function Calib_2p_Callback(hObject, eventdata, handles)
% hObject    handle to Calib_2p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Calib_2p



function Temperaure_Callback(hObject, eventdata, handles)
% hObject    handle to Temperaure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Temperaure as text
%        str2double(get(hObject,'String')) returns contents of Temperaure as a double


% --- Executes during object creation, after setting all properties.
function Temperaure_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Temperaure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
