
# Import Pyqt4 packages
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *
# Import system packages
import sys
import pandas as pd
import scipy as sp
from scipy.signal import medfilt
from scipy import stats
import numpy as np
import os
from os.path import dirname, join
import math
import time
import pickle
# Import matplotlib packages
import matplotlib
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
# Initilize some varibles

filter_span = 5 # Span of digital filter, default 5, can be adjusted accordingly
f_OD_density = 1 # target density to OD ratio e.g. 2x10^6 cells/OD, then this value should be 2e6


# Functions used for calculation
    ######################################################
    # Separate the raw data by time and plot each segment#
    ######################################################
        
def Data_chop(Lightscheme,Rawdata,filter_span):
    # Getting the time that separates each light condtion, and return the fitting coefficients
    Light_on = [] 
    Time = Lightscheme['Time']
    Switchtime = [Time.iloc[0]] # adding the first time point
    for i in range(len(Lightscheme)-1):
        if Lightscheme['Light'][i]!=Lightscheme['Light'][i+1]:
            Light_on = (Light_on + ['On']) if (Lightscheme['Light'][i] >0) else (Light_on + ['Off'])   
            Switchtime.append(Lightscheme['Time'][i])            
    Switchtime.append(Lightscheme['Time'].iloc[-1]) # adding the last time point
    Light_on = (Light_on + ['On']) if (Lightscheme['Light'].iloc[-1] >0) else (Light_on + ['Off'])
    Processed_data = []
    fit_data = []
    fit_parameters = pd.DataFrame(columns = ['slope', 'intercept', 'r_value', 'p_value', 'std_err'])
    for i in range(len(Switchtime)-1):
        Y = Rawdata[Switchtime[i]:Switchtime[i+1]]
        X = Time[Switchtime[i]:Switchtime[i+1]]
        Y_filt = medfilt(Y,kernel_size = filter_span)
        Processed_data = Processed_data + list(Y_filt)
        fitting = stats.linregress(X,Y_filt)
        Y_fit = fitting.slope*X+fitting.intercept
        fit_data = fit_data + list(Y_fit.values)
        fit_parameters.loc[i] = fitting
    fit_data = fit_data + [Rawdata[len(Lightscheme)-1]] # Add thelast datapoint that was missed in calculation
    fit_parameters['Light_on'] = Light_on

    return fit_parameters,fit_data

def MIMS_Func(MIMS_file,Blank_file,conf,lightscheme_file,MOD):
    # initialize all variables from data input
    data = pd.read_csv(MIMS_file)
    blankdata = pd.read_csv(Blank_file)
    O2_blank = (blankdata.O18+blankdata.O16)/blankdata.Ar
    Lightscheme = pd.read_csv(lightscheme_file)
    # Load configurations for MIMS calculation
    Temperature = conf.Temperature
    Salinity = conf.Salinity
    DO16_0_signal =conf.DO_0_singnal # Zero 32_O2 signal/Ar signal
    DO18_0_signal = conf.DO18_0_singal # Zero 36_O2 signal/Ar signal
    # Calculating saturation oxygen concentration
    Ts = math.log((298.15-Temperature)/(273.15+Temperature))
    DO_0 = 1.43905*math.exp(2.00907 + 3.22014*Ts + 4.0501*Ts**2 + 4.94457*Ts**3 - 0.256847*Ts**4 + 3.88767*Ts**5)
    Fs = math.exp((-0.00624523 - 0.00737614*Ts - 0.010341*Ts**2 - 0.00817083*Ts**3)*Salinity-4.88682*(10**-7)*Salinity**2)
    DO_sat = Fs*DO_0*1000/32
    # Dissolved gas concentration to signal (normalized to Ar) ratio
    C2S = DO_sat/(np.mean(O2_blank)-(DO16_0_signal.values[0]+DO18_0_signal.values[0])) 
    O18 = np.interp(Lightscheme.Time,data.Time, data['O18'])
    O16 = np.interp(Lightscheme.Time,data.Time, data['O16'])
    Ar = np.interp(Lightscheme.Time,data.Time, data['Ar'])  
    O18_norm = C2S*(O18/Ar - float(DO18_0_signal))
    O16_norm = C2S*(O16/Ar - float(DO16_0_signal))
    TO2 = O18_norm+O16_norm
    DO_conc,DO_data = Data_chop(Lightscheme,TO2,filter_span)

    Oxygen_evolution = []
    Oxygen_respiration = []
    for i in DO_conc.index:
        if DO_conc.Light_on[i] == 'On':
            Oxygen_evolution = Oxygen_evolution + [DO_conc.slope[i]]
        else: Oxygen_respiration = Oxygen_respiration + [-1*DO_conc.slope[i]]
    Oxygen_evolution = [-1*Oxygen_respiration[0]]+Oxygen_evolution
    Light_level = Lightscheme.groupby('Light').var().index.tolist()
    DO_result = pd.DataFrame({'Light_level' : Light_level, 'Oxygen_evolution':Oxygen_evolution/MOD,'Oxygen_respiration':Oxygen_respiration/MOD})
    DO_result['Oxygen_evolution_gross'] = DO_result[['Oxygen_evolution','Oxygen_respiration']].sum(axis = 1)
    DO_result['Respiration_to_Photosynthesis'] = [DO_result['Oxygen_respiration'][i]/DO_result['Oxygen_evolution_gross'][i] if DO_result['Oxygen_evolution_gross'][i]!=0 else np.nan for i in DO_result.index  ]

    return DO_result,DO_data,TO2

def pH_Func(pH_file,conf,lightscheme_file,MOD):
    data = pd.read_csv(pH_file)
    pH = data.pH
    Lightscheme = pd.read_csv(lightscheme_file)
    Alk_measure = float(conf.Alklinity)
    Temperature = conf.Temperature
    Salinity = conf.Salinity
    P_concentration = float(conf.P_concentration) #umol/L
    B_concentration = float(conf.B_concentration) #umol/L
    Si_concentration = float(conf.Si_concentration) #umol/L
    Titration_pH = conf.Titration_pH
    H = 10**(-pH)
    # pK values from Dickson et al., 1987
    # For salinity range between 20-40
    if (Salinity.values[0] > 20 and Salinity.values[0] < 40):
        pK1 = 845.0/(Temperature+273.15)+3.248-0.0098*Salinity+0.000087*Salinity**2     # (+-0.017)
        pK2 = 1377.3/(Temperature+273.15) +4.824-0.0185*Salinity+0.000122*Salinity**2     # (+-0.026)
    elif (Salinity.values[0] > 0 and Salinity.values[0] < 20):
        pK1 = (-849.39/(Temperature+273.15)+19.894-3.0189*math.log(Temperature+273.15))*Salinity**(1/2)+0.00668*Salinity #(+-0.017)
        pK2 = (-690.59/(Temperature+273.15) +17.176-2.6719*math.log(Temperature+273.15))*Salinity**(1/2)+0.0217*Salinity #(+-0.032) 
    else: 
        import warnings
        warnings.warn('Salinity out of range')
    # Calculating pK_P (Phosphate) values using equations from Dickson, 2007(SOP)
    # From here pK value is ln(K) instead of log(K)
    pK_P1 = (-4576.752/(Temperature+273.15)+115.525-18.453*math.log(Temperature+273.15)+(0.69171-106.736/(Temperature+273.15))*Salinity**(1/2)-(0.65643/(Temperature+273.15)+0.01844)*Salinity)
    pK_P2 = (-8814.715/(Temperature+273.15)+172.0833-27.927*math.log(Temperature+273.15)+(1.3566-160.34/(Temperature+273.15))*Salinity**(1/2)+(0.37335/(Temperature+273.15)-0.05778)*Salinity)
    pK_P3 = (-3070.75/(Temperature+273.15)-18.141+(2.8119+17.27039/(Temperature+273.15))*Salinity**(1/2)+(-44.99486/(Temperature+273.15)-0.09984)*Salinity)
    K_P1 = math.exp(pK_P1)
    K_P2 = math.exp(pK_P2)
    K_P3 = math.exp(pK_P3)
    Alk_P = P_concentration*((K_P1*K_P2*H+2*K_P1*K_P2*K_P3-H**3)/(H**3+K_P1*H**2+K_P1*K_P2*H+K_P1*K_P2*K_P3))

    # Calculating k_W to get the concentration of [OH-] in the medium system
    pK_W = -13847.26/(Temperature+273.15) +148.9652-23.6521*math.log(Temperature+273.15)+(118.67/(Temperature+273.15) - 5.977 + 1.0495*math.log(Temperature+273.15))*Salinity**(1/2)-0.01615*Salinity
    OH_level = 10**6*math.exp(pK_W)/H

    # Calculating pK_Si (Silicon) values using equations from Dickson, 2007(SOP)
    I_str = 19.924*Salinity/(1000-1.005*Salinity) # Ionc strength calculated based on Salinity
    pK_Si = (-8904.2/(Temperature+273.15) + 117.385 - 19.334*math.log(Temperature+273.15) + (-458.79/(Temperature+273.15)+3.5913)*I_str**(1/2) + (188.74/(Temperature+273.15) - 1.5998)*I_str +(-12.1652/(Temperature+273.15) + 0.07871)*I_str**2 + math.log(1-0.001005*Salinity))
    K_Si = math.exp(pK_Si)
    Alk_Si = Si_concentration/(1+H/K_Si)
  
     # Calculating pK_B (Boron) values using equations from Dickson, 2007(SOP)
    pK_B = ((-8966.9-2890.53*Salinity**(1/2)-77.942*Salinity+1.728*Salinity**(3/2)-0.0996*Salinity**2)/(Temperature+273.15)+148.0248+137.1942*Salinity**(1/2)+1.62142*Salinity+(-24.4344-25.085*Salinity**(1/2)-0.2474*Salinity)*math.log(Temperature+273.15)+0.053105*(Temperature+273.15)*Salinity**(1/2))
    K_B = math.exp(pK_B)
    Alk_B = B_concentration/(1+H/K_B)

    # Calculating Carbonic alkalinity based on the titration result and pH measured during experiment
    Alk = Alk_measure - Alk_P - Alk_B - Alk_Si - OH_level 

    # Gettting K value for calculation
    K1 = 10**(-1*pK1.values[0])
    K2 = 10**(-1*pK2.values[0])
    # Calculate carbon speciation
    CO2 = ((Alk/10**6)*H**2)/(K1*(H+2*K2))
    HCO3 = CO2*K1/H
    CO3 = HCO3*K2/H
    CO2 = CO2[0:len(Lightscheme)]*10**6
    HCO3 = HCO3[0:len(Lightscheme)]*10**6
    CO3 = CO3[0:len(Lightscheme)]*10**6
    TIC = (CO2+HCO3+CO3)

    C_conc,C_data = Data_chop(Lightscheme,TIC,filter_span)

    Carbon_uptake = []
    Carbon_respiration = []
    for i in C_conc.index:
        if C_conc.Light_on[i] == 'On':
            Carbon_uptake = Carbon_uptake + [-1*C_conc.slope[i]]
        else: Carbon_respiration = Carbon_respiration + [C_conc.slope[i]]
    Carbon_uptake = [-Carbon_respiration[0]]+Carbon_uptake
    Light_level = Lightscheme.groupby('Light').var().index.tolist()
    C_result = pd.DataFrame({'Light_level' : Light_level, 'Carbon_uptake':Carbon_uptake/MOD,'Carbon_respiration':Carbon_respiration/MOD})
    C_result['C_Respiration_to_Photosynthesis'] = [C_result['Carbon_respiration'][i]/C_result['Carbon_uptake'][i] if C_result['Carbon_uptake'][i]!=0 else np.nan for i in C_result.index  ]

    return C_result, C_data, TIC


# Here I used a online code for populating table with Pandas dataframe
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)



class Ui_Form(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.setupUi(self)
    
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("AlgaeSystem Python_Ver 2.1"))
        Form.resize(1400, 500)
        self.groupBox = QtGui.QGroupBox(Form)
        self.groupBox.setGeometry(QtCore.QRect(10, 10, 401, 351))
        self.groupBox.setFlat(False)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayoutWidget = QtGui.QWidget(self.groupBox)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(120, 60, 251, 250))
        self.verticalLayoutWidget.setObjectName(_fromUtf8("verticalLayoutWidget"))
        self.verticalLayout = QtGui.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.Cell_line = QtGui.QComboBox(self.verticalLayoutWidget)
        self.Cell_line.setObjectName(_fromUtf8("Cell_line"))
        self.verticalLayout.addWidget(self.Cell_line)
        self.Medium = QtGui.QComboBox(self.verticalLayoutWidget)
        self.Medium.setObjectName(_fromUtf8("Medium"))
        self.verticalLayout.addWidget(self.Medium)
        self.Experiment = QtGui.QComboBox(self.verticalLayoutWidget)
        self.Experiment.setObjectName(_fromUtf8("Experiment"))
        self.verticalLayout.addWidget(self.Experiment)
        self.Treatment = QtGui.QComboBox(self.verticalLayoutWidget)
        self.Treatment.setObjectName(_fromUtf8("Treatment"))
        self.verticalLayout.addWidget(self.Treatment)
        self.Time_point = QtGui.QComboBox(self.verticalLayoutWidget)
        self.Time_point.setObjectName(_fromUtf8("Time_point"))
        self.verticalLayout.addWidget(self.Time_point)
        self.Path_link = QtGui.QTextBrowser(self.groupBox)
        self.Path_link.setGeometry(QtCore.QRect(30, 30, 221, 40))
        self.Path_link.setObjectName(_fromUtf8("Path_link"))
        self.Submit_btn = QtGui.QPushButton(self.groupBox)
        self.Submit_btn.setGeometry(QtCore.QRect(270, 311, 110, 41))
        self.Submit_btn.setObjectName(_fromUtf8("Submit_btn"))
        self.Browse_btn = QtGui.QPushButton(self.groupBox)
        self.Browse_btn.setGeometry(QtCore.QRect(290, 30, 81, 21))
        self.Browse_btn.setObjectName(_fromUtf8("Browse_btn"))
        self.verticalLayoutWidget_2 = QtGui.QWidget(self.groupBox)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(30, 50, 125, 271))
        self.verticalLayoutWidget_2.setObjectName(_fromUtf8("verticalLayoutWidget_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.Cell_line_check = QtGui.QCheckBox(self.verticalLayoutWidget_2)
        self.Cell_line_check.setObjectName(_fromUtf8("Cell_line_check"))
        self.verticalLayout_2.addWidget(self.Cell_line_check)
        self.Medium_check = QtGui.QCheckBox(self.verticalLayoutWidget_2)
        self.Medium_check.setObjectName(_fromUtf8("Medium_check"))
        self.verticalLayout_2.addWidget(self.Medium_check)
        self.Experiment_check = QtGui.QCheckBox(self.verticalLayoutWidget_2)
        self.Experiment_check.setObjectName(_fromUtf8("Experiment_check"))
        self.verticalLayout_2.addWidget(self.Experiment_check)
        self.Treatment_check = QtGui.QCheckBox(self.verticalLayoutWidget_2)
        self.Treatment_check.setObjectName(_fromUtf8("Treatment_check"))
        self.verticalLayout_2.addWidget(self.Treatment_check)
        self.Time_check = QtGui.QCheckBox(self.verticalLayoutWidget_2)
        self.Time_check.setObjectName(_fromUtf8("Time_check"))
        self.verticalLayout_2.addWidget(self.Time_check)
        self.Msgbox = QtGui.QTextBrowser(self.groupBox)
        self.Msgbox.setGeometry(QtCore.QRect(29, 312, 241, 31))
        self.Msgbox.setObjectName(_fromUtf8("Msgbox"))
        self.verticalLayoutWidget.raise_()
        self.Submit_btn.raise_()
        self.Browse_btn.raise_()
        self.verticalLayoutWidget_2.raise_()
        self.Msgbox.raise_()
        self.Table_Button = QtGui.QPushButton(Form)
        self.Table_Button.setGeometry(QtCore.QRect(130, 450, 141, 32))
        self.Table_Button.setObjectName(_fromUtf8("Table_Button"))
        self.Sample_list_box = QtGui.QComboBox(Form)
        self.Sample_list_box.setGeometry(QtCore.QRect(110, 420, 301, 26))
        self.Sample_list_box.setObjectName(_fromUtf8("Sample_list_box"))
        self.label = QtGui.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(20, 430, 91, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.Result_table = QtGui.QTableWidget(Form)
        self.Result_table.setGeometry(QtCore.QRect(420, 300, 950, 180))
        self.Result_table.setObjectName(_fromUtf8("Result_table"))
        self.Result_plot = QtGui.QWidget(Form)
        self.Result_plot.setGeometry(QtCore.QRect(420, 30, 950, 260))
        self.Result_plot.setObjectName(_fromUtf8("Result_plot"))

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Algae IDSP System Python_Ver 2.1", None))
        self.groupBox.setTitle(_translate("Form", "Criteria Selection", None))
        self.Path_link.setText(_translate("Form", "Choose the master index file", None))
        self.Submit_btn.setText(_translate("Form", "OK", None))
        self.Browse_btn.setText(_translate("Form", "Browse", None))
        self.Cell_line_check.setText(_translate("Form", "Cell line", None))
        self.Medium_check.setText(_translate("Form", "Medium", None))
        self.Experiment_check.setText(_translate("Form", "Experiment", None))
        self.Treatment_check.setText(_translate("Form", "Treatment", None))
        self.Time_check.setText(_translate("Form", "Time point", None))
        self.Table_Button.setText(_translate("Form", "Generate tables", None))
        self.label.setText(_translate("Form", "Select sample", None))
        self.Browse_btn.clicked.connect(self.selectFile)
        self.Submit_btn.clicked.connect(self.Calculation)
        self.Table_Button.clicked.connect(self.Generate_Table)

    
        
  

    def selectFile(self):
        global filename
        global data
        filename = QFileDialog.getOpenFileName(self, "Open csv", os.getcwd(),"csv Files (*.csv)")
        self.Path_link.setText(filename)
        f = open(filename, 'r')
        with f:
            data = pd.read_csv(f)
            List1 = data.groupby('Cell_line').var().index.tolist() 
            self.Cell_line.clear()
            self.Cell_line.addItems(List1)
            List2 = data.groupby('Medium').var().index.tolist() 
            self.Medium.clear()
            self.Medium.addItems(List2)
            List3 = data.groupby('Experiment').var().index.tolist()
            self.Experiment.clear()
            self.Experiment.addItems(List3)
            List4 = data.groupby('Treatment').var().index.tolist()
            self.Treatment.clear()
            self.Treatment.addItems(List4)
            List5 = data.groupby('Time_point').var().index.tolist()
            self.Time_point.clear()
            self.Time_point.addItems(List5)


  
    def Calculation(self):
        check_list = {}
        if self.Cell_line_check.isChecked():
            Select1 = str(self.Cell_line.currentText())
            check_list['Cell_line'] = Select1
        if self.Medium_check.isChecked():
            Select2 = str(self.Medium.currentText())
            check_list['Medium'] = Select2
        if self.Experiment_check.isChecked():
            Select3 = str(self.Experiment.currentText())
            check_list['Experiment'] = Select3
        if self.Treatment_check.isChecked():
            Select4 = str(self.Treatment.currentText())
            check_list['Treatment'] = Select4
        if self.Time_check.isChecked():
            Select5 = str(self.Time_point.currentText())
            check_list['Time_point'] = Select5
        NewData = data.loc[(data[list(check_list)] == pd.Series(check_list)).all(axis=1)]
        if (len(NewData) == 0):
            self.Msgbox.setText('Nothing found, please change selection!')
        else:
            self.Msgbox.setText('%s results found' %len(NewData))
            sample_list = [i[:-5] for i in NewData['MIMS_Name']]
            self.Sample_list_box.clear()
            self.Sample_list_box.addItems(sample_list)    
            # First generate a folder for results
            directory = filename.replace(filename.split('/')[-1],'')
            global Inquery_path
            Inquery_path =directory+'Results/'+time.strftime("%Y_%m_%d-%H_%M_%S")+'/'
            if not os.path.exists(Inquery_path):
                os.makedirs(Inquery_path)
            # Start calculations



            # Getting all of the corresponding file names
            Dataframe_flag = 0
            MIMS_frame_data = pd.DataFrame()
            MIMS_raw_data = pd.DataFrame()
            pH_frame_data = pd.DataFrame()
            pH_raw_data = pd.DataFrame()
            for row_num in NewData.index:
                MOD =  NewData['Measurement_OD'][row_num]*f_OD_density
                MIMS_file = directory+'MIMS/'+ NewData['MIMS_Name'][row_num]+'.csv'
                pH_file = directory+'pH/'+ NewData['pH_Name'][row_num]+'.csv'
                Blank_file = directory+'Blank/'+ NewData['Blank_Reference'][row_num]+'.csv'
                lightscheme_file = directory+'Conf/'+ NewData['Light_Scheme'][row_num]+'.csv'
                conf_name = NewData['Configuration'][row_num]
                conf_all = pd.read_csv(filename.replace(filename.split('/')[-1],'Conf/Configuration.csv',1))
                conf = conf_all[conf_all.Date == conf_name]
                MIMS_result,MIMS_data,MIMS_raw = MIMS_Func(MIMS_file,Blank_file,conf,lightscheme_file,MOD)
                MIMS_frame_data[NewData['MIMS_Name'][row_num]] = MIMS_data
                MIMS_raw_data[NewData['MIMS_Name'][row_num]] = MIMS_raw
                pH_result, pH_data, pH_raw = pH_Func(pH_file,conf,lightscheme_file,MOD)
                pH_frame_data[NewData['pH_Name'][row_num]] = pH_data
                pH_raw_data[NewData['pH_Name'][row_num]] = pH_raw                                

                if Dataframe_flag==0:
                    MIMS_frame = [MIMS_result]
                    pH_frame = [pH_result]
                    Dataframe_flag = 1 
                else:
                    MIMS_frame.append(MIMS_result)
                    pH_frame.append(pH_result)
                # Getting results from inquery and store in corresponding Dataframess
            # Rename all sample names to keep consistancy
            MIMS_frame_data.columns = sample_list
            pH_frame_data.columns = sample_list
            MIMS_raw_data.columns = sample_list
            pH_raw_data.columns = sample_list
            MIMS_frame_result = pd.concat(MIMS_frame, keys = sample_list)
            pH_frame_result = pd.concat(pH_frame, keys = sample_list)
            results = pd.concat([MIMS_frame_result,pH_frame_result],axis=1).T.drop_duplicates().T
            pickle_file = open(Inquery_path+'inquery_results.pkl','wb')
            with pickle_file:
                pickle.dump(results,pickle_file)
            MIMS_frame_data.to_csv(Inquery_path+'MIMS_frame_data.csv')
            MIMS_raw_data.to_csv(Inquery_path+'MIMS_raw_data.csv')
            pH_frame_data.to_csv(Inquery_path+'pH_frame_data.csv')
            pH_raw_data.to_csv(Inquery_path+'pH_raw_data.csv')
                
    def Generate_Table(self):
        # Generate table
        sample_name = str(self.Sample_list_box.currentText())
        pickle_file = open(Inquery_path+'inquery_results.pkl','rb')
        with pickle_file:
            results = pickle.load(pickle_file)
        table_content = results.loc[sample_name]
        self.Result_table.clear()
        self.Result_table.setColumnCount(table_content.shape[1])
        self.Result_table.setRowCount(table_content.shape[0])
        HorHeaders = []
        for n,key in enumerate(table_content.keys()):
            HorHeaders.append(key)
            for m, item in enumerate(table_content[key]):
                newitem = QtGui.QTableWidgetItem(str(item))
                self.Result_table.setItem(m,n,newitem)
        self.Result_table.setHorizontalHeaderLabels(HorHeaders)
        self.Result_table.resizeColumnsToContents()
        self.Result_table.resizeRowsToContents()
        # Generate embedded figure for quality control
        # Cleanup the layout that has already exist
        QObjectCleanupHandler().add(self.Result_plot.layout())
        MIMS_frame_data = pd.read_csv(Inquery_path+'MIMS_frame_data.csv')
        MIMS_raw_data = pd.read_csv(Inquery_path+'MIMS_raw_data.csv')
        pH_frame_data = pd.read_csv(Inquery_path+'pH_frame_data.csv')
        pH_raw_data = pd.read_csv(Inquery_path+'pH_raw_data.csv')
        self.Result_plot.fig = Figure()
        self.Result_plot.canvas = FigureCanvas(self.Result_plot.fig)
        self.Result_plot.vbox = QtGui.QVBoxLayout()
        self.Result_plot.setLayout(self.Result_plot.vbox)
        self.Result_plot.vbox.addWidget(self.Result_plot.canvas)
        Subplot1= self.Result_plot.fig.add_subplot(121)
        Subplot1.plot(MIMS_raw_data[sample_name],'b-')
        Subplot1.plot(MIMS_frame_data[sample_name],'r.', markersize = 1.5)
        Subplot1.set_title('Oxygen signal')
        Subplot1.set_ylim([int(min(MIMS_frame_data[sample_name])-10), int(max(MIMS_frame_data[sample_name])+10)])
        Subplot2 = self.Result_plot.fig.add_subplot(122)
        Subplot2.plot(pH_raw_data[sample_name],'b-')
        Subplot2.plot(pH_frame_data[sample_name],'r.', markersize = 1.5)
        Subplot2.set_ylim([int(min(pH_frame_data[sample_name])-10), int(max(pH_frame_data[sample_name])+10)])
        Subplot2.set_title('Carbon signal')
        self.Result_plot.canvas.draw()



if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex = Ui_Form()
    ex.show()
    sys.exit(app.exec_())
